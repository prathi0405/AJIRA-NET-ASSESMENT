class Device:
    def __init__(self, type, name):
        self.type = type
        self.name = name
        self.strength = 0
        self.adjacent = []